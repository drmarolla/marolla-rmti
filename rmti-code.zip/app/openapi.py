"""OpenAPI 3.0 description and a /docs page (Swagger UI loaded from a CDN
in the visitor's browser; the server itself needs no extra packages)."""
from .routes import API_VERSION

_unit = {"type": "number", "minimum": 0, "maximum": 1}
_C = {"type": "integer", "enum": [1, 2, 3, 4, 5],
      "description": "Consequence index (Table 2): 1=0.10 Insignificant, 2=0.30 Minor, "
                     "3=0.50 Moderate, 4=0.75 Major, 5=1.00 Severe. Default 5."}
_N = {"type": "number", "minimum": 1, "maximum": 10_000_000_000,
      "description": "Population / cohort size (drives the advisory E_log and the per-capita rate)."}

_disaster_input = {
    "type": "object", "required": ["N", "L", "E_sel", "V", "rho_now"], "additionalProperties": False,
    "properties": {
        "N": _N, "L": {**_unit, "description": "Hazard likelihood"},
        "E_sel": {**_unit, "description": "Selected exposure ('E' is accepted as an alias)"},
        "V": {**_unit, "description": "Vulnerability"},
        "rho_now": {**_unit, "description": "Current resilience (must be < 1 if rho_after is given)"},
        "rho_after": {**_unit, "description": "Post-investment resilience (optional)"},
        "C": _C},
    "example": {"N": 1100000, "L": 0.875, "E_sel": 0.8, "V": 0.8,
                "rho_now": 0.25, "rho_after": 0.48, "C": 4}}

_onc_input = {
    "type": "object", "required": ["N", "L", "rho_now"], "additionalProperties": False,
    "description": "Provide exactly one of V, albi_grade, albi_grade_counts. E is optional "
                   "(defaults to the log-normalised helper from N). Provide C or bclc_stage, not both.",
    "properties": {
        "N": _N, "L": {**_unit, "description": "Annual HCC incidence-derived likelihood"},
        "E": _unit, "V": _unit,
        "albi_grade": {"type": "integer", "enum": [1, 2, 3]},
        "albi_grade_counts": {"type": "object", "example": {"1": 10, "2": 18, "3": 1}},
        "rho_now": _unit, "rho_after": _unit, "C": _C,
        "bclc_stage": {"type": "string", "enum": ["BCLC0", "BCLC_A", "EARLY_INT", "BCLC_B", "BCLC_CD"]}},
    "example": {"N": 100000, "L": 0.30, "E": 0.65, "albi_grade": 2,
                "rho_now": 0.20, "rho_after": 0.50, "bclc_stage": "BCLC_CD"}}


def _rank_body(item_schema, desc):
    item = {"allOf": [item_schema, {"type": "object", "required": ["label"],
                                    "properties": {"label": {"type": "string", "maxLength": 60}}}]}
    return {"type": "object", "required": ["items"], "additionalProperties": False,
            "properties": {"items": {"type": "array", "minItems": 1, "maxItems": 100,
                                     "items": item, "description": desc}}}


_ok = {"200": {"description": "OK", "content": {"application/json": {"schema": {"type": "object"}}}},
       "400": {"description": "Validation error: {error:{code,message}}"},
       "429": {"description": "Rate limited; see Retry-After header"}}


def _post(summary, schema, tag):
    return {"post": {"summary": summary, "tags": [tag], "responses": _ok,
                     "requestBody": {"required": True, "content": {"application/json": {"schema": schema}}}}}


def _get(summary, tag, params=None):
    g = {"summary": summary, "tags": [tag], "responses": _ok}
    if params:
        g["parameters"] = params
    return {"get": g}


EXTENDED_DESCRIPTION = '## About this API\n\nThe **Risk Mechanism Theory Index (RMTI)** is a deterministic, rubric-based way to rank where risk-reduction effort\nmatters most. It rests on Risk Mechanism Design and Theory (Marolla, 2018, 2025). It does not forecast events. It\nturns a handful of bounded inputs into a score, a fixed tier and a plain-language posture, so that two people\nfeeding in the same inputs always get the same answer.\n\n### The calculation\n\n| Symbol | Meaning |\n|---|---|\n| **L** | Likelihood of the hazard or event |\n| **E** | Exposure: how much of the population or asset base is in the path of the hazard |\n| **V** | Vulnerability: how easily exposure becomes harm |\n| **rho** | Strength of the risk-reducing mechanism already in place (`rho_now`), or planned (`rho_after`) |\n| **C** | Consequence severity, from a fixed five-step scale (0.10, 0.30, 0.50, 0.75, 1.00) |\n\n* **Inherent risk:** `IR = L x E x V`\n* **Residual risk:** `R = IR x (1 - rho)`, the score after existing or planned mitigation\n* **Expected-annual-loss index:** `EAL = L x C x (1 - rho)`, an ordinal severity index, not a monetary loss\n* **Equity rate:** per 1,000,000 people (disaster) or per 1,000,000 at-risk patients (oncology)\n\nScores fall into five **pre-registered tiers**, identical for every request: Low (below 0.05), Moderate\n(below 0.15), High (below 0.35), Severe (below 0.60) and Critical (0.60 and above). Supplying `rho_now` and\n`rho_after` shows how far a proposed intervention would move an asset or cohort (`risk_reduction_pct`).\n\n### Two applications, one engine\n\n**Disaster and urban risk** (`/v1/disaster/...`). Score a city or asset, rank up to 100, or retrieve the published\neight-city cohort (Bamako, Lagos, Lilongwe, Nairobi, Dar es Salaam, Lusaka, Pacific Palisades, Altadena).\n\n**Oncology: hepatocellular carcinoma (HCC) surveillance triage** (`/v1/oncology/...`). Score a cohort or stratum\nfor surveillance prioritisation. Vulnerability can come from liver reserve (ALBI grade 1 to 3, or a distribution of\ngrades), consequence from the stage at which a missed tumour would be found (BCLC 0 through C-D), and rho from the\nstrength of the surveillance programme.\n\n### What the API does and does not do\n\n* It performs the published arithmetic exactly, with decimal rounding that matches the manuscript tables.\n* It validates every input and rejects unknown fields, so a typo cannot silently change a result.\n* It stores nothing. Request bodies and query strings are never logged.\n* **Educational and research use only.** It is not a forecast, an engineering assessment, an actuarial figure or a\n  diagnostic tool. The HCC application is a decision-support reading and has not been validated against prospective\n  incident HCC. It is not a medical device.\n* **Never send patient-identifiable information.** Send only cohort-level or stratum-level numbers.\n\n### How to cite\n\nCite this API together with the RMTI reference implementation (concept DOI 10.5281/zenodo.21445892).\n'


def spec():
    return {
        "openapi": "3.0.3",
        "info": {
            "title": "RMTI API", "version": API_VERSION,
            "description": EXTENDED_DESCRIPTION,
            "license": {"name": "Apache-2.0", "url": "https://www.apache.org/licenses/LICENSE-2.0"}},
        "tags": [{"name": "framework"}, {"name": "disaster"}, {"name": "oncology"}],
        "paths": {
            "/health": _get("Liveness check", "framework"),
            "/v1/framework": _get("Fixed tier table, consequence scale and anchors", "framework"),
            "/v1/exposure": _get("Advisory log-normalised exposure E_log", "framework", [
                {"name": "N", "in": "query", "required": True, "schema": {"type": "number"}},
                {"name": "domain", "in": "query", "schema": {"type": "string",
                                                              "enum": ["disaster", "oncology"]}}]),
            "/v1/disaster/assess": _post("Score one asset or city", _disaster_input, "disaster"),
            "/v1/disaster/rank": _post("Score and rank a portfolio (max 100)",
                                       _rank_body(_disaster_input, "Assets to rank"), "disaster"),
            "/v1/disaster/cohort": _get("Published eight-asset validation cohort, ranked", "disaster"),
            "/v1/multi": _post("Multi-hazard, multi-category form (Eq. 3/5) — not field-validated", {
                "type": "object", "required": ["hazards", "weights"], "additionalProperties": False,
                "properties": {
                    "N": _N,
                    "weights": {"type": "object", "description": "social, economic, environmental; must sum to 1",
                                "example": {"social": 0.4, "economic": 0.3, "environmental": 0.3}},
                    "hazards": {"type": "array", "maxItems": 10, "items": {"type": "object"}}}}, "disaster"),
            "/v1/oncology/assess": _post("Score one HCC cohort/stratum", _onc_input, "oncology"),
            "/v1/oncology/rank": _post("Score and rank strata (max 100)",
                                       _rank_body(_onc_input, "Strata to rank; use non-identifying labels"),
                                       "oncology"),
            "/v1/oncology/cohorts": _get("Published HCC cohorts and Pearl-protocol aetiologies", "oncology"),
        },
    }


DOCS_HTML = """<!doctype html>
<html lang="en"><head><meta charset="utf-8"><title>RMTI API docs</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui.css"></head>
<body><div id="ui"></div>
<script src="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5/swagger-ui-bundle.js"></script>
<script>window.ui = SwaggerUIBundle({url: "/openapi.json", dom_id: "#ui"});</script>
</body></html>"""
