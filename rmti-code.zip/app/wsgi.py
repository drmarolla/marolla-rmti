"""WSGI application for the RMTI API (standard library only).

Privacy: request bodies and query strings are NEVER logged or stored. The
only thing written to the log is "METHOD PATH STATUS milliseconds".
"""
import hmac
import json
import os
import sys
import time
from urllib.parse import parse_qsl

from . import routes
from .guard import ConcurrencyGate, RateLimiter
from .openapi import DOCS_HTML, spec
from .validation import ApiError

MAX_BODY_BYTES = 32 * 1024
MAX_QUERY_CHARS = 512

# (method, path) -> (handler, kind)   kind: "get" | "query" | "body"
ROUTES = {
    ("GET", "/"): (lambda: routes.info(), "get"),
    ("GET", "/health"): (lambda: {"status": "ok", "api_version": routes.API_VERSION,
                                  "framework_version": routes.FRAMEWORK_VERSION}, "get"),
    ("GET", "/v1/framework"): (routes.framework, "get"),
    ("GET", "/v1/exposure"): (routes.exposure, "query"),
    ("GET", "/v1/disaster/cohort"): (routes.disaster_cohort, "get"),
    ("GET", "/v1/oncology/cohorts"): (routes.oncology_cohorts, "get"),
    ("POST", "/v1/disaster/assess"): (routes.disaster_assess, "body"),
    ("POST", "/v1/disaster/rank"): (routes.disaster_rank, "body"),
    ("POST", "/v1/multi"): (routes.multi, "body"),
    ("POST", "/v1/oncology/assess"): (routes.oncology_assess, "body"),
    ("POST", "/v1/oncology/rank"): (routes.oncology_rank, "body"),
}
KNOWN_PATHS = {p for _, p in ROUTES} | {"/docs", "/openapi.json"}
CACHEABLE = {"/v1/framework", "/v1/disaster/cohort", "/v1/oncology/cohorts", "/openapi.json"}
NO_LIMIT = {"/health"}

_REASONS = {200: "OK", 204: "No Content", 400: "Bad Request", 401: "Unauthorized", 404: "Not Found",
            405: "Method Not Allowed", 411: "Length Required", 413: "Payload Too Large",
            415: "Unsupported Media Type", 429: "Too Many Requests",
            500: "Internal Server Error", 503: "Service Unavailable"}


def _reject_constant(name):
    raise ValueError(f"{name} is not valid JSON")


def _env_int(name, default):
    try:
        return int(os.environ.get(name, default))
    except ValueError:
        return default


def make_app(limiter=None, gate=None, api_key=None, log=True):
    limiter = limiter or RateLimiter(
        per_client_rpm=_env_int("RMTI_CLIENT_RPM", 30), per_client_burst=_env_int("RMTI_CLIENT_BURST", 15),
        global_rpm=_env_int("RMTI_GLOBAL_RPM", 60), global_burst=_env_int("RMTI_GLOBAL_BURST", 40))
    gate = gate or ConcurrencyGate(_env_int("RMTI_MAX_CONCURRENCY", 16))
    api_key = api_key if api_key is not None else os.environ.get("RMTI_API_KEY", "")

    def client_ip(environ):
        # Behind the host's proxy the real client is the LAST X-Forwarded-For entry
        # (the one the proxy appended); earlier entries can be forged by the caller.
        xff = environ.get("HTTP_X_FORWARDED_FOR", "")
        if xff:
            return xff.split(",")[-1].strip()[:64]
        return environ.get("REMOTE_ADDR", "unknown")

    def respond(start_response, status, obj=None, *, raw=None, ctype="application/json",
                extra=None, head=False, cache=False):
        if raw is None:
            raw = b"" if obj is None else json.dumps(obj, allow_nan=False).encode("utf-8")
        headers = [
            ("Content-Type", ctype + "; charset=utf-8"),
            ("Content-Length", str(len(raw))),
            ("Access-Control-Allow-Origin", "*"),
            ("Access-Control-Allow-Methods", "GET, POST, OPTIONS"),
            ("Access-Control-Allow-Headers", "Content-Type, X-API-Key"),
            ("X-Content-Type-Options", "nosniff"),
            ("Referrer-Policy", "no-referrer"),
            ("Cache-Control", "public, max-age=300" if cache else "no-store"),
        ] + (extra or [])
        start_response(f"{status} {_REASONS.get(status, 'Status')}", headers)
        return [b""] if head else [raw]

    def error(start_response, status, code, message, head=False, extra=None):
        return respond(start_response, status, {"error": {"code": code, "message": message}},
                       head=head, extra=extra)

    def app(environ, start_response):
        t0 = time.perf_counter()
        method = environ.get("REQUEST_METHOD", "GET").upper()
        path = environ.get("PATH_INFO", "/") or "/"
        if len(path) > 1:
            path = path.rstrip("/")
        status_box = {}

        def sr(status, headers):
            status_box["s"] = status.split(" ", 1)[0]
            start_response(status, headers)

        head = method == "HEAD"
        if head:
            method = "GET"
        try:
            out = _dispatch(environ, sr, method, path, head)
        except Exception as exc:                       # never leak internals or input
            print(f"ERROR {type(exc).__name__} on {method} {path}", file=sys.stderr, flush=True)
            if "s" in status_box:       # response already started
                raise
            out = error(sr, 500, "internal_error", "Unexpected server error.", head)
        if log:
            ms = (time.perf_counter() - t0) * 1000
            print(f"{environ.get('REQUEST_METHOD')} {path} {status_box.get('s', '?')} {ms:.0f}ms",
                  file=sys.stderr, flush=True)
        return out

    def _dispatch(environ, sr, method, path, head):
        if method == "OPTIONS":
            return respond(sr, 204, raw=b"")
        if path not in KNOWN_PATHS:
            return error(sr, 404, "not_found", "Unknown path. See /docs.", head)
        if path == "/docs" and method == "GET":
            return respond(sr, 200, raw=DOCS_HTML.encode(), ctype="text/html", head=head)
        if path == "/openapi.json" and method == "GET":
            return respond(sr, 200, spec(), head=head, cache=True)
        entry = ROUTES.get((method, path))
        if entry is None:
            allow = ", ".join(sorted({m for m, p in ROUTES if p == path}))
            return error(sr, 405, "method_not_allowed", f"Use {allow or 'GET'} for this path.", head,
                         extra=[("Allow", allow or "GET")])

        if path not in NO_LIMIT:
            if not gate.acquire():
                return error(sr, 503, "busy", "Server busy; retry shortly.", head,
                             extra=[("Retry-After", "2")])
            try:
                return _limited(environ, sr, method, path, entry, head)
            finally:
                gate.release()
        return _limited(environ, sr, method, path, entry, head, limit=False)

    def _limited(environ, sr, method, path, entry, head, limit=True):
        if limit:
            ok, wait = limiter.check(client_ip(environ))
            if not ok:
                return error(sr, 429, "rate_limited", f"Too many requests. Retry in {wait}s.", head,
                             extra=[("Retry-After", str(wait))])
        handler, kind = entry
        try:
            if kind == "get":
                return respond(sr, 200, handler(), head=head, cache=path in CACHEABLE)
            if kind == "query":
                qs = environ.get("QUERY_STRING", "")
                if len(qs) > MAX_QUERY_CHARS:
                    raise ApiError(400, "query_too_long", "Query string too long")
                return respond(sr, 200, handler(dict(parse_qsl(qs, keep_blank_values=True))), head=head)

            # POST with JSON body
            if api_key:
                supplied = environ.get("HTTP_X_API_KEY", "")
                if not hmac.compare_digest(supplied.encode(), api_key.encode()):
                    return error(sr, 401, "unauthorized", "A valid X-API-Key header is required.", head)
            if "json" not in environ.get("CONTENT_TYPE", "").lower():
                return error(sr, 415, "unsupported_media_type", "Send Content-Type: application/json.", head)
            try:
                length = int(environ.get("CONTENT_LENGTH") or "")
            except ValueError:
                return error(sr, 411, "length_required", "Content-Length header is required.", head)
            if length < 0:
                return error(sr, 411, "length_required", "Invalid Content-Length.", head)
            if length > MAX_BODY_BYTES:
                return error(sr, 413, "payload_too_large", f"Body must be at most {MAX_BODY_BYTES} bytes.", head)
            raw = environ["wsgi.input"].read(length)
            try:
                body = json.loads(raw.decode("utf-8"), parse_constant=_reject_constant)
            except (ValueError, UnicodeDecodeError):
                return error(sr, 400, "invalid_json", "Body is not valid JSON.", head)
            return respond(sr, 200, handler(body), head=head)
        except ApiError as e:
            return error(sr, e.status, e.code, e.message, head)

    return app


application = make_app()
