"""Abuse and cost guards. In-memory, thread-safe, dependency-free.

Why this exists: the free hosting tier has a monthly allowance (instance
hours and bandwidth). Per-client and global rate limits keep a burst of
traffic from using it up, so the service degrades to HTTP 429 for the
excess requests instead of the whole service being suspended.
"""
import threading
import time


class TokenBucket:
    __slots__ = ("capacity", "tokens", "rate", "stamp")

    def __init__(self, capacity, rate, now):
        self.capacity, self.tokens, self.rate, self.stamp = capacity, capacity, rate, now

    def take(self, now):
        self.tokens = min(self.capacity, self.tokens + (now - self.stamp) * self.rate)
        self.stamp = now
        if self.tokens >= 1:
            self.tokens -= 1
            return True
        return False

    def retry_after(self):
        return max(1, int((1 - self.tokens) / self.rate) + 1)


class RateLimiter:
    """Per-client bucket plus one global bucket.

    per_client_rpm / global_rpm are sustained requests per minute; `burst`
    values allow short spikes. Memory is bounded: at most `max_clients`
    buckets are kept (oldest evicted first).
    """

    def __init__(self, per_client_rpm=30, per_client_burst=15,
                 global_rpm=60, global_burst=40, max_clients=5000, clock=time.monotonic):
        self._clock = clock
        self._lock = threading.Lock()
        self._pc = (per_client_burst, per_client_rpm / 60.0)
        self._clients = {}
        self._max = max_clients
        now = clock()
        self._global = TokenBucket(global_burst, global_rpm / 60.0, now)

    def check(self, client):
        """Return (allowed, retry_after_seconds)."""
        with self._lock:
            now = self._clock()
            if not self._global.take(now):
                return False, self._global.retry_after()
            b = self._clients.get(client)
            if b is None:
                if len(self._clients) >= self._max:
                    self._clients.pop(next(iter(self._clients)))
                b = self._clients[client] = TokenBucket(self._pc[0], self._pc[1], now)
            if not b.take(now):
                self._global.tokens += 1          # don't charge global for a refused client
                return False, b.retry_after()
            return True, 0


class ConcurrencyGate:
    """Refuse (HTTP 503) rather than queue unboundedly on a 0.1-CPU instance."""

    def __init__(self, limit=16):
        self._sem = threading.BoundedSemaphore(limit)

    def acquire(self):
        return self._sem.acquire(blocking=False)

    def release(self):
        self._sem.release()
