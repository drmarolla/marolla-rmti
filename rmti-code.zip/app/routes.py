"""Endpoint logic. Pure functions: (query/body) -> JSON-serialisable dict.

All arithmetic is delegated to the unmodified v2.1.0 reference modules
(core.rmti_core, disaster_climate.rmti_ssa, oncology.rmti_hcc). Nothing in
this file re-implements an RMTI equation.
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from core import rmti_core as core                      # noqa: E402
from disaster_climate import rmti_ssa as ssa            # noqa: E402
from oncology import rmti_hcc as hcc                    # noqa: E402

from .validation import (                               # noqa: E402
    ApiError, MAX_HAZARDS, N_HARD_MAX, bad, check_fields, integer_in,
    items_list, label, num, require_object, rho_pair,
)

API_VERSION = "1.0.0"
FRAMEWORK_VERSION = core.__version__

NOTICE_GENERAL = (
    "Relative, rubric-based index for education and research. Scores are not "
    "forecasts, engineering assessments or actuarial figures. EAL is an ordinal "
    "severity index, not a monetary loss."
)
NOTICE_ONCOLOGY = (
    "Educational and research use only. Not a medical device; not clinically "
    "validated; does not diagnose, predict outcomes for individual patients, or "
    "recommend treatment. Decisions about patient care remain with treating "
    "clinicians. Do NOT submit patient-identifiable information."
)

# The paper (Tables 4-6) and the Calculator workbook score these three
# comparator cities at baseline only. The v2.1.0 reference code additionally
# carries scenario rho_after values for them that appear in neither source.
# Until that is resolved, the cohort endpoint serves them baseline-only.
BASELINE_ONLY = {"Nairobi", "Dar es Salaam", "Lusaka"}


def _meta(domain_notice):
    return {"notice": domain_notice, "api_version": API_VERSION,
            "framework_version": FRAMEWORK_VERSION}


# --------------------------------------------------------------------------
# Input parsing
# --------------------------------------------------------------------------
_DIS_FIELDS = {"N", "L", "E_sel", "E", "V", "rho_now", "rho_after", "C"}


def _parse_disaster(d, where="request body", with_label=False):
    allowed = _DIS_FIELDS | ({"label"} if with_label else set())
    check_fields(d, allowed, where)
    if "E" in d and "E_sel" in d:
        raise bad("conflicting_fields", f"Provide only one of 'E' / 'E_sel' in {where}")
    key = "E_sel" if "E_sel" in d else "E"
    kw = {
        "N": num(d, "N", 1, N_HARD_MAX, where=where),
        "L": num(d, "L", 0, 1, where=where),
        "E_sel": num(d, key, 0, 1, where=where),
        "V": num(d, "V", 0, 1, where=where),
        "rho_now": num(d, "rho_now", 0, 1, where=where),
        "rho_after": num(d, "rho_after", 0, 1, required=False, where=where),
        "C": integer_in(d, "C", {1, 2, 3, 4, 5}, required=False, default=5, where=where),
    }
    rho_pair(kw["rho_now"], kw["rho_after"], where)
    return kw


_ONC_FIELDS = {"N", "L", "E", "V", "albi_grade", "albi_grade_counts",
               "rho_now", "rho_after", "C", "bclc_stage"}


def _parse_albi_counts(c, where):
    if not isinstance(c, dict) or not c:
        raise bad("invalid_type", f"'albi_grade_counts' must be an object like "
                                  f"{{\"1\": 10, \"2\": 18, \"3\": 1}} in {where}")
    out = {}
    for k, v in c.items():
        if k not in ("1", "2", "3"):
            raise bad("invalid_value", f"'albi_grade_counts' keys must be \"1\", \"2\", \"3\" in {where}")
        if isinstance(v, bool) or not isinstance(v, int) or v < 0 or v > 1_000_000_000:
            raise bad("invalid_value", f"'albi_grade_counts' values must be non-negative integers in {where}")
        out[int(k)] = v
    if sum(out.values()) == 0:
        raise bad("invalid_value", f"'albi_grade_counts' must include at least one patient in {where}")
    return out


def _parse_oncology(d, where="request body", with_label=False):
    allowed = _ONC_FIELDS | ({"label"} if with_label else set())
    check_fields(d, allowed, where)
    n = num(d, "N", 1, N_HARD_MAX, where=where)

    v_sources = [k for k in ("V", "albi_grade", "albi_grade_counts") if k in d]
    if len(v_sources) != 1:
        raise bad("invalid_vulnerability",
                  f"Provide exactly one of 'V', 'albi_grade' or 'albi_grade_counts' in {where}")
    src = v_sources[0]
    if src == "V":
        v = num(d, "V", 0, 1, where=where)
    elif src == "albi_grade":
        v = hcc.albi_to_v(integer_in(d, "albi_grade", {1, 2, 3}, where=where))
    else:
        v = hcc.albi_cohort_v(_parse_albi_counts(d["albi_grade_counts"], where))

    if "C" in d and "bclc_stage" in d:
        raise bad("conflicting_fields", f"Provide only one of 'C' / 'bclc_stage' in {where}")
    if "bclc_stage" in d:
        stage = d["bclc_stage"]
        if stage not in hcc.C_LADDER:
            raise bad("invalid_value", f"'bclc_stage' must be one of {sorted(hcc.C_LADDER)} in {where}")
        c = hcc.C_LADDER[stage]
    else:
        c = integer_in(d, "C", {1, 2, 3, 4, 5}, required=False, default=5, where=where)

    e = num(d, "E", 0, 1, required=False, where=where)
    e_source = "provided"
    if e is None:
        e, e_source = hcc.exposure_from_population(n), "log-normalised from N (HCC bounds)"

    kw = {
        "N": n, "L": num(d, "L", 0, 1, where=where), "E": e, "V": v,
        "rho_now": num(d, "rho_now", 0, 1, where=where),
        "rho_after": num(d, "rho_after", 0, 1, required=False, where=where),
        "C": c,
    }
    rho_pair(kw["rho_now"], kw["rho_after"], where)
    return kw, {"V_source": src, "E_source": e_source}


def _parse_ranked_rows(body, parser, with_provenance=False):
    rows, seen = {}, set()
    for i, item in enumerate(items_list(body)):
        where = f"items[{i}]"
        require_object(item, where)
        name = label(item, where)
        if name in seen:
            raise bad("duplicate_label", f"Duplicate label '{name}' in {where}")
        seen.add(name)
        parsed = parser({k: v for k, v in item.items() if k != "label"}, where)
        rows[name] = parsed[0] if with_provenance else parsed
    return rows


# --------------------------------------------------------------------------
# Generic framework information
# --------------------------------------------------------------------------
def info():
    return {
        "name": "RMTI API",
        "description": "Risk Mechanism Theory Index scoring for disaster/urban risk and "
                       "oncology (HCC) surveillance triage. Stateless; nothing you send is stored.",
        "equations": {"IR": "L * E * V", "R": "IR * (1 - rho)", "EAL": "L * C * (1 - rho)",
                      "E_log": "(log10 N - log10 Nmin) / (log10 Nmax - log10 Nmin)",
                      "equity": "EAL / N, reported per 1,000,000"},
        "docs": "/docs", "openapi": "/openapi.json",
        "endpoints": [
            "GET  /health", "GET  /v1/framework", "GET  /v1/exposure?N=...&domain=disaster|oncology",
            "POST /v1/disaster/assess", "POST /v1/disaster/rank", "GET  /v1/disaster/cohort",
            "POST /v1/multi",
            "POST /v1/oncology/assess", "POST /v1/oncology/rank", "GET  /v1/oncology/cohorts",
        ],
        "citation": "Marolla, C. RMTI reference implementation, concept DOI 10.5281/zenodo.21445892",
        **_meta(NOTICE_GENERAL),
    }


def framework():
    return {
        "tiers": [{"tier": lbl, "upper_bound_exclusive": (None if thr >= 1e8 else thr),
                   "posture": core.TIER_POSTURE[lbl]} for thr, lbl in core.TIER],
        "consequence_scale_C": {str(k): v for k, v in core.C_INFRA.items()},
        "rho_typology_anchors": core.RHO_TYPOLOGY_ANCHORS,
        "disaster_exposure_bounds": {"N_min": core.N_MIN, "N_max": core.N_MAX},
        "oncology": {"albi_grade_to_V": {str(k): v for k, v in hcc.ALBI_V.items()},
                     "rho_anchors": hcc.RHO_ANCHORS,
                     "bclc_stage_to_C_index": hcc.C_LADDER,
                     "exposure_bounds": {"N_min": hcc.N_MIN_HCC, "N_max": hcc.N_MAX_HCC}},
        **_meta(NOTICE_GENERAL),
    }


def exposure(query):
    check_fields(query, {"N", "domain"}, "query string")
    try:
        n = float(query["N"])
    except (KeyError, ValueError):
        raise bad("invalid_type", "query parameter 'N' (a number) is required")
    if not (1 <= n <= N_HARD_MAX):
        raise bad("out_of_range", f"'N' must be within [1, {N_HARD_MAX}]")
    domain = query.get("domain", "disaster")
    if domain == "disaster":
        val, bounds = core.e_log(n), (core.N_MIN, core.N_MAX)
    elif domain == "oncology":
        val, bounds = hcc.exposure_from_population(n), (hcc.N_MIN_HCC, hcc.N_MAX_HCC)
    else:
        raise bad("invalid_value", "'domain' must be 'disaster' or 'oncology'")
    return {"N": n, "domain": domain, "E_log": round(val, 3),
            "bounds": {"N_min": bounds[0], "N_max": bounds[1]},
            "advisory": "E_log is an advisory baseline; analysts may enter their own rubric-based E.",
            **_meta(NOTICE_ONCOLOGY if domain == "oncology" else NOTICE_GENERAL)}


# --------------------------------------------------------------------------
# Disaster / urban risk
# --------------------------------------------------------------------------
def disaster_assess(body):
    require_object(body)
    kw = _parse_disaster(body)
    return {"inputs": kw, "result": core.assess(**kw), **_meta(NOTICE_GENERAL)}


def disaster_rank(body):
    rows = _parse_ranked_rows(body, lambda d, w: _parse_disaster(d, w))
    ranked = core.rank_cohort(rows)
    return {"count": len(ranked), "ranked": ranked,
            "ordering": "tier severity (most severe first), then EAL_now descending; "
                        "priority_in_tier resets at each tier boundary",
            **_meta(NOTICE_GENERAL)}


def _ranked_disaster_cohort():
    ranked = core.rank_cohort(ssa._scoreable_cohort(
        {n: ({k: v for k, v in r.items() if k != "rho_after"} if n in BASELINE_ONLY else r)
         for n, r in ssa.COHORT.items()}))
    for r in ranked:
        meta = ssa.COHORT[r["name"]]
        r["country"], r["hazard"] = meta["country"], meta["hazard"]
    return ranked


_DISASTER_COHORT = _ranked_disaster_cohort()


def disaster_cohort():
    return {"count": len(_DISASTER_COHORT), "ranked": _DISASTER_COHORT,
            "sources": "World Bank AFRI-RES compendium (2023) via Marolla (2026); "
                       "January 2025 California wildfire cases from the RMTI Calculator workbook.",
            "note": "Nairobi, Dar es Salaam and Lusaka are baseline-only, as in the paper's Tables 4-6.",
            **_meta(NOTICE_GENERAL)}


def multi(body):
    require_object(body)
    check_fields(body, {"N", "hazards", "weights"}, "request body")
    n = num(body, "N", 1, N_HARD_MAX, required=False)
    weights = require_object(body.get("weights"), "'weights'")
    check_fields(weights, set(core.CATEGORIES), "'weights'")
    w = {c: num(weights, c, 0, 1, where="'weights'") for c in core.CATEGORIES}
    hz = body.get("hazards")
    if not isinstance(hz, list) or not (1 <= len(hz) <= MAX_HAZARDS):
        raise bad("invalid_body", f"'hazards' must be an array of 1-{MAX_HAZARDS} objects")
    hazards = []
    for i, h in enumerate(hz):
        where = f"hazards[{i}]"
        require_object(h, where)
        check_fields(h, {"name", "L", "categories", "rho_hazard", "C"}, where)
        if not isinstance(h.get("name"), str) or not (1 <= len(h["name"]) <= 60):
            raise bad("invalid_label", f"'name' must be a string of 1-60 characters in {where}")
        cats = require_object(h.get("categories"), f"{where}.categories")
        check_fields(cats, set(core.CATEGORIES), f"{where}.categories")
        parsed_cats = {}
        for c in core.CATEGORIES:
            cw = f"{where}.categories.{c}"
            cat = require_object(cats.get(c), cw)
            check_fields(cat, {"E", "V", "rho"}, cw)
            parsed_cats[c] = {k: num(cat, k, 0, 1, where=cw) for k in ("E", "V", "rho")}
        hazards.append({"name": h["name"], "L": num(h, "L", 0, 1, where=where),
                        "categories": parsed_cats,
                        "rho_hazard": num(h, "rho_hazard", 0, 1, where=where),
                        "C": integer_in(h, "C", {1, 2, 3, 4, 5}, where=where)})
    try:
        res = core.assess_multi(n, hazards, w) if n is not None else core.score_multi(hazards, w)
    except ValueError as e:      # category weights must sum to 1
        raise bad("invalid_weights", str(e))
    out = {"result": res, **_meta(NOTICE_GENERAL)}
    if res["R"] > 1:
        out["warning"] = ("R exceeds 1.0: with several severe hazards the multi-hazard form is not "
                          "bounded to [0, 1] (paper Sec. 3.2). Interpret as extreme cumulative risk "
                          "beyond the tier scale. This extension is not field-validated.")
    else:
        out["warning"] = "The multi-hazard extension (Eq. 3/5) is not field-validated against a real case."
    return out


# --------------------------------------------------------------------------
# Oncology (HCC surveillance triage)
# --------------------------------------------------------------------------
def oncology_assess(body):
    require_object(body)
    kw, prov = _parse_oncology(body)
    return {"inputs": kw, "provenance": prov, "result": hcc.assess_patient(**kw),
            **_meta(NOTICE_ONCOLOGY)}


def oncology_rank(body):
    rows = _parse_ranked_rows(body, lambda d, w: _parse_oncology(d, w), with_provenance=True)
    ranked = hcc.rank_cohort_hcc(rows)
    return {"count": len(ranked), "ranked": ranked,
            "ordering": "tier severity (most severe first), then EAL_now descending; "
                        "priority_in_tier resets at each tier boundary",
            "advice": "Use generic, non-identifying labels such as 'cohort A'.",
            **_meta(NOTICE_ONCOLOGY)}


def _ranked_onc(cohort):
    ranked = hcc.rank_cohort_hcc(hcc._scoreable(cohort))
    for r in ranked:
        r["incidence"] = cohort[r["name"]]["incidence"]
    return ranked


_ONC_PUBLISHED = _ranked_onc(hcc.PUBLISHED_COHORTS)
_ONC_PEARL = _ranked_onc(hcc.PEARL_COHORTS)


def oncology_cohorts():
    return {"published_cohorts": _ONC_PUBLISHED, "pearl_protocol_aetiologies": _ONC_PEARL,
            "note": "Published cohort-level illustrations from the RMTI-HCC reference "
                    "implementation; they are not patient-level predictions.",
            **_meta(NOTICE_ONCOLOGY)}
