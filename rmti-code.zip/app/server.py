"""Run the API: `python -m app.server`  (reads PORT, default 8000).

Standard-library threaded WSGI server; no third-party packages. The hosting
platform terminates HTTPS in front of it.
"""
import os
import sys
from socketserver import ThreadingMixIn
from wsgiref.simple_server import WSGIRequestHandler, WSGIServer, make_server

from .wsgi import application


class QuietHandler(WSGIRequestHandler):
    timeout = 10                       # drop slow/stalled clients after 10 s

    def log_message(self, *args):      # the app logs "METHOD PATH STATUS ms" itself
        pass


class ThreadedServer(ThreadingMixIn, WSGIServer):
    daemon_threads = True
    request_queue_size = 32


def main():
    port = int(os.environ.get("PORT", "8000"))
    srv = make_server("0.0.0.0", port, application, server_class=ThreadedServer,
                      handler_class=QuietHandler)
    print(f"RMTI API listening on 0.0.0.0:{port}", file=sys.stderr, flush=True)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
