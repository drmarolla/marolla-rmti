"""RMTI shared core."""
