# License scope: code vs. teaching and narrative materials

The top-level `LICENSE` file (Apache License 2.0) in this repository covers
**source code only**:

- `core/rmti_core.py`
- `disaster_climate/rmti_ssa.py`
- `oncology/rmti_hcc.py`
- `tests/test_rmti.py`

It does **not** cover the underlying rubrics, scoring bands, the log-normalized
exposure transform's design, the severity layer's design, or any teaching or
narrative materials distributed alongside this code, including but not
limited to:

- The four ENVR E-241 teaching presentations (`1_Risk_Mechanism_Theory.pdf`
  through `4_Climate_Resilient_Infrastructure.pdf`)
- The RMTI Calculator spreadsheet's rubric text, worked examples, and
  proprietary formatting (the *formulas* reproduce the Apache-licensed
  equations and are not separately restricted; the surrounding pedagogical
  material is)
- Any interactive teaching sandbox or web application built on this code that
  reproduces the rubric wording, tier descriptions, or worked scenario text

Those materials remain **all rights reserved** under:

> © 2025 Cesar Marolla. The Risk Mechanism Theory Index (RMTI) — its rubrics,
> scoring bands, log-normalized exposure transform, severity layer and
> overall design — is proprietary. Developed for ENVR E-241 Risk by Design.
> Not for redistribution or commercial use without written permission.

## Why the split

The Apache 2.0 grant on the code exists so the *arithmetic* — the equations,
the tier thresholds as numbers, the consequence lookup as numbers — is freely
usable, inspectable, and citable, consistent with the Natural Hazards
manuscript's own Code Availability statement and the Zenodo archive
(concept DOI 10.5281/zenodo.21445892).

That grant was never intended to release the pedagogical framing built around
those numbers for the ENVR E-241 course, or the specific rubric language used
to elicit L, E, V and ρ scores from an analyst. A derivative work is free to
reimplement `R = L * E * V * (1 - rho)` and the fixed tier thresholds; it is
not free to reproduce the course's rubric text or presentation slides without
separate permission.

## In practice

- **Citing or extending the equations in a paper or your own code:** covered
  by Apache 2.0. Attribute per `CITATION.cff`.
- **Teaching from the ENVR E-241 slide decks, or redistributing them:**
  requires separate written permission from the copyright holder.
- **Building a new interface (web app, EHR integration, calculator) that
  implements the equations from scratch, in your own words:** the equations
  are free to use; write your own rubric prose and UI copy rather than
  copying the course materials' wording.
- **Building on the `RMTI_Calculator_Dr_Marolla.xlsx` workbook or the
  interactive sandbox that ships with it:** these embed the rubric wording,
  tier descriptions, and course branding directly, and are governed by the
  proprietary notice above unless the copyright holder states otherwise for
  that specific artifact.

If you are unsure which side of this line something falls on, ask before
redistributing.
